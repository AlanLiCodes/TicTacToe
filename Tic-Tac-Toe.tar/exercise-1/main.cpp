#include <cstdlib>
#include <iostream>
#include <system_error>
#include "GameState.h"
using namespace std;

//0 is player X
//1 is play O

int main(){
    GameState game;

    game.start();

    return 0;
}